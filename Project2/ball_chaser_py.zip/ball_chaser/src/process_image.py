import rospy
import rospkg
from ball_chaser.srv import drivetotarget,drivetotargetRequest
from sensor_msgs.msg import Image
image=Image()

def drive_robot( lin_x ,ang_z):
    service_request.linear_x=lin_x
    service_request.angular_z=ang_z
    result=ball_chaser_client(service_request)



def process_image_callback(img):
   
    height1=img.step
    print(height1)

    white_pixel=255
    left_counter=0
    right_counter=0
    front_counter=0

    for i in the range (1,(img.height*img.step)):
    
 


    

rospy.init_node('camera_images')
rospy.wait_for_service('ball_chaser/command_robot')
ball_chaser_client=rospy.ServiceProxy('/ball_chaser/command_robot',drivetotarget)
service_request=drivetotargetRequest()
image=rospy.Subscriber('/camera/rgb/image_raw',Image,process_image_callback)
rospy.spin()

result=ball_chaser_client(ball_chaser_object)