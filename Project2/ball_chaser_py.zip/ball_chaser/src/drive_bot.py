import rospy
from ball_chaser.srv import drivetotarget, drivetotargetResponse
from geometry_msgs.msg import Twist

def callback(request):
    twist.linear.x = request.linear_x
    twist.angular.z = request.angular_z
    vel_pub.publish(twist)





rospy.init_node('command')
vel_service=rospy.Service('/ball_chaser/command_robot',drivetotarget,callback)
vel_pub=rospy.Publisher('/cmd_vel',Twist,queue_size=1)
twist=Twist()
rate=rospy.Rate(1)
rospy.spin()